"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import type { ColumnDef } from "@tanstack/react-table";
import { DataTable } from "@/components/tables/DataTable";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  addPayrollAdjustment,
  upsertEmployeeSalaryConfig,
  upsertGradeCompensationConfig,
} from "@/server/actions/payroll";
import type {
  PayrollDivisionSummaryRow,
  PayrollFinanceSummary,
  PayrollGradeCompensationRow,
  PayrollPeriodRow,
  PayrollResultRow,
  PayrollSalaryConfigRow,
} from "../payroll/PayrollClient";

type Props = {
  canManage: boolean;
  activePeriodId: string | null;
  periods: PayrollPeriodRow[];
  financeSummary: PayrollFinanceSummary;
  divisionSummaries: PayrollDivisionSummaryRow[];
  results: PayrollResultRow[];
  salaryConfigs: PayrollSalaryConfigRow[];
  gradeCompensations: PayrollGradeCompensationRow[];
};

type SalaryDraft = {
  employeeId: string;
  employeeLabel: string;
  baseSalaryAmount: string;
  notes: string;
};

type GradeDraft = {
  gradeId: string;
  gradeLabel: string;
  allowanceAmount: string;
  bonusKinerja80: string;
  bonusKinerja90: string;
  bonusKinerja100: string;
  bonusKinerjaTeam80: string;
  bonusKinerjaTeam90: string;
  bonusKinerjaTeam100: string;
  bonusDisiplin80: string;
  bonusDisiplin90: string;
  bonusDisiplin100: string;
  bonusPrestasi140: string;
  bonusPrestasi165: string;
};

type AdjustmentDraft = {
  employeeId: string;
  adjustmentType: "ADDITION" | "DEDUCTION";
  amount: string;
  reason: string;
};

function formatCurrency(amount: number) {
  return `Rp ${amount.toLocaleString("id-ID", { maximumFractionDigits: 2 })}`;
}

function asInput(value: number | null) {
  return value == null ? "" : String(value);
}

function createSalaryDraft(row?: PayrollSalaryConfigRow): SalaryDraft {
  return {
    employeeId: row?.employeeId ?? "",
    employeeLabel: row ? `${row.employeeName} · ${row.employeeCode}` : "",
    baseSalaryAmount: asInput(row?.baseSalaryAmount ?? null),
    notes: row?.notes ?? "",
  };
}

function createGradeDraft(row?: PayrollGradeCompensationRow): GradeDraft {
  return {
    gradeId: row?.gradeId ?? "",
    gradeLabel: row?.gradeName ?? "",
    allowanceAmount: asInput(row?.allowanceAmount ?? null),
    bonusKinerja80: asInput(row?.bonusKinerja80 ?? null),
    bonusKinerja90: asInput(row?.bonusKinerja90 ?? null),
    bonusKinerja100: asInput(row?.bonusKinerja100 ?? null),
    bonusKinerjaTeam80: asInput(row?.bonusKinerjaTeam80 ?? null),
    bonusKinerjaTeam90: asInput(row?.bonusKinerjaTeam90 ?? null),
    bonusKinerjaTeam100: asInput(row?.bonusKinerjaTeam100 ?? null),
    bonusDisiplin80: asInput(row?.bonusDisiplin80 ?? null),
    bonusDisiplin90: asInput(row?.bonusDisiplin90 ?? null),
    bonusDisiplin100: asInput(row?.bonusDisiplin100 ?? null),
    bonusPrestasi140: asInput(row?.bonusPrestasi140 ?? null),
    bonusPrestasi165: asInput(row?.bonusPrestasi165 ?? null),
  };
}

function createAdjustmentDraft(employeeId = ""): AdjustmentDraft {
  return {
    employeeId,
    adjustmentType: "DEDUCTION",
    amount: "",
    reason: "",
  };
}

export default function FinanceDashboardClient({
  canManage,
  activePeriodId,
  periods,
  financeSummary,
  divisionSummaries,
  results,
  salaryConfigs,
  gradeCompensations,
}: Props) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [salaryOpen, setSalaryOpen] = useState(false);
  const [gradeOpen, setGradeOpen] = useState(false);
  const [adjustmentOpen, setAdjustmentOpen] = useState(false);
  const [salaryDraft, setSalaryDraft] = useState<SalaryDraft>(createSalaryDraft());
  const [gradeDraft, setGradeDraft] = useState<GradeDraft>(createGradeDraft());
  const [adjustmentDraft, setAdjustmentDraft] = useState<AdjustmentDraft>(createAdjustmentDraft());

  async function runAction(action: () => Promise<{ error?: string; success?: boolean }>) {
    setPending(true);
    setError(null);
    setSuccess(null);
    try {
      const result = await action();
      if (result?.error) {
        setError(result.error);
        return false;
      }
      setSuccess("Perubahan berhasil disimpan.");
      router.refresh();
      return true;
    } finally {
      setPending(false);
    }
  }

  const divisionColumns: ColumnDef<PayrollDivisionSummaryRow>[] = useMemo(
    () => [
      { header: "Divisi", accessorKey: "divisionName" },
      { header: "Karyawan", accessorKey: "employeeCount" },
      {
        header: "Total THP",
        accessorKey: "totalTakeHomePay",
        cell: ({ row }) => <span>{formatCurrency(row.original.totalTakeHomePay)}</span>,
      },
      {
        header: "Addition",
        accessorKey: "totalAdditions",
        cell: ({ row }) => <span>{formatCurrency(row.original.totalAdditions)}</span>,
      },
      {
        header: "Deduction",
        accessorKey: "totalDeductions",
        cell: ({ row }) => <span>{formatCurrency(row.original.totalDeductions)}</span>,
      },
    ],
    []
  );

  const resultColumns: ColumnDef<PayrollResultRow>[] = useMemo(
    () => [
      {
        header: "Karyawan",
        accessorKey: "employeeName",
        cell: ({ row }) => (
          <div className="space-y-0.5">
            <p className="font-medium text-slate-900">{row.original.employeeName}</p>
            <p className="text-xs text-slate-500">
              {row.original.employeeCode} · {row.original.divisionName} · {row.original.employeeGroup}
            </p>
          </div>
        ),
      },
      { header: "Grade", accessorKey: "gradeName" },
      {
        header: "THP",
        accessorKey: "takeHomePay",
        cell: ({ row }) => <span>{formatCurrency(row.original.takeHomePay)}</span>,
      },
    ],
    []
  );

  const salaryColumns: ColumnDef<PayrollSalaryConfigRow>[] = useMemo(
    () => [
      {
        header: "Karyawan",
        accessorKey: "employeeName",
        cell: ({ row }) => (
          <div className="space-y-0.5">
            <p className="font-medium text-slate-900">{row.original.employeeName}</p>
            <p className="text-xs text-slate-500">{row.original.employeeCode} · {row.original.divisionName}</p>
          </div>
        ),
      },
      {
        header: "Gaji Pokok",
        accessorKey: "baseSalaryAmount",
        cell: ({ row }) => <span>{formatCurrency(row.original.baseSalaryAmount ?? 0)}</span>,
      },
      {
        header: "Terakhir Update",
        accessorKey: "updatedAt",
      },
      {
        header: "Aksi",
        id: "salary-action",
        cell: ({ row }) =>
          canManage ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSalaryDraft(createSalaryDraft(row.original));
                setSalaryOpen(true);
              }}
            >
              Atur
            </Button>
          ) : null,
      },
    ],
    [canManage]
  );

  const gradeColumns: ColumnDef<PayrollGradeCompensationRow>[] = useMemo(
    () => [
      { header: "Grade", accessorKey: "gradeName" },
      {
        header: "Tunjangan",
        accessorKey: "allowanceAmount",
        cell: ({ row }) => <span>{formatCurrency(row.original.allowanceAmount ?? 0)}</span>,
      },
      {
        header: "Bonus Kinerja (100%)",
        accessorKey: "bonusKinerja100",
        cell: ({ row }) => <span>{formatCurrency(row.original.bonusKinerja100 ?? 0)}</span>,
      },
      {
        header: "Aksi",
        id: "grade-action",
        cell: ({ row }) =>
          canManage ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setGradeDraft(createGradeDraft(row.original));
                setGradeOpen(true);
              }}
            >
              Atur
            </Button>
          ) : null,
      },
    ],
    [canManage]
  );

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-sm text-slate-500">Karyawan</p>
          <p className="mt-2 text-xl font-semibold text-slate-900">{financeSummary.employeeCount}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-sm text-slate-500">Total THP</p>
          <p className="mt-2 text-xl font-semibold text-slate-900">{formatCurrency(financeSummary.totalTakeHomePay)}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-sm text-slate-500">Total Addition</p>
          <p className="mt-2 text-xl font-semibold text-slate-900">{formatCurrency(financeSummary.totalAdditions)}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-sm text-slate-500">Total Deduction</p>
          <p className="mt-2 text-xl font-semibold text-slate-900">{formatCurrency(financeSummary.totalDeductions)}</p>
        </div>
      </div>

      {error ? <div className="rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</div> : null}
      {success ? <div className="rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{success}</div> : null}

      <div className="grid gap-6 lg:grid-cols-[300px_minmax(0,1fr)]">
        <div className="space-y-3">
          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <p className="text-sm font-medium text-slate-900">Periode Finance</p>
            <p className="mt-1 text-xs text-slate-500">Pilih periode untuk dashboard dan adjustment.</p>
          </div>
          {periods.map((period) => {
            const isActive = period.id === activePeriodId;
            return (
              <Link
                key={period.id}
                href={`/finance?periodId=${period.id}`}
                className={`block rounded-xl border p-4 transition-colors ${
                  isActive ? "border-slate-900 bg-slate-900 text-white" : "border-slate-200 bg-white hover:border-slate-300"
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <p className="font-medium">{period.periodCode}</p>
                  <Badge variant="outline">{period.status}</Badge>
                </div>
                <p className={`mt-2 text-sm ${isActive ? "text-slate-200" : "text-slate-500"}`}>{period.periodLabel}</p>
              </Link>
            );
          })}
        </div>

        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-3">
            {activePeriodId ? (
              <a
                className="inline-flex h-9 items-center justify-center rounded-md border border-slate-200 bg-white px-4 text-sm font-medium text-slate-900 shadow-xs"
                href={`/payroll/${activePeriodId}/export.xlsx`}
              >
                Export Excel
              </a>
            ) : null}
            <Link
              className="inline-flex h-9 items-center justify-center rounded-md border border-slate-200 bg-white px-4 text-sm font-medium text-slate-900 shadow-xs"
              href={activePeriodId ? `/payroll?periodId=${activePeriodId}` : "/payroll"}
            >
              Buka Modul Payroll
            </Link>
            {canManage && activePeriodId ? (
              <Button
                variant="outline"
                onClick={() => {
                  setAdjustmentDraft(createAdjustmentDraft(results[0]?.employeeId ?? ""));
                  setAdjustmentOpen(true);
                }}
              >
                Tambah Adjustment
              </Button>
            ) : null}
          </div>

          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-slate-900">Summary per Divisi</h3>
            <DataTable data={divisionSummaries} columns={divisionColumns} searchKey="divisionName" searchPlaceholder="Cari divisi..." />
          </div>

          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-slate-900">Ringkasan Hasil Payroll</h3>
            <DataTable data={results} columns={resultColumns} searchKey="employeeName" searchPlaceholder="Cari karyawan..." />
          </div>

          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-slate-900">Pengaturan Gaji Pokok Karyawan</h3>
            <DataTable data={salaryConfigs} columns={salaryColumns} searchKey="employeeName" searchPlaceholder="Cari karyawan..." />
          </div>

          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-slate-900">Master Bonus & Tunjangan Grade</h3>
            <DataTable data={gradeCompensations} columns={gradeColumns} searchKey="gradeName" searchPlaceholder="Cari grade..." />
          </div>
        </div>
      </div>

      <Dialog open={salaryOpen} onOpenChange={setSalaryOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Atur Gaji Pokok</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input value={salaryDraft.employeeLabel} disabled />
            <Input
              type="number"
              placeholder="Gaji Pokok"
              value={salaryDraft.baseSalaryAmount}
              onChange={(event) => setSalaryDraft((v) => ({ ...v, baseSalaryAmount: event.target.value }))}
            />
            <Input
              placeholder="Catatan (opsional)"
              value={salaryDraft.notes}
              onChange={(event) => setSalaryDraft((v) => ({ ...v, notes: event.target.value }))}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSalaryOpen(false)} disabled={pending}>Batal</Button>
            <Button
              disabled={pending}
              onClick={async () => {
                const ok = await runAction(() =>
                  upsertEmployeeSalaryConfig({
                    employeeId: salaryDraft.employeeId,
                    baseSalaryAmount: salaryDraft.baseSalaryAmount,
                    notes: salaryDraft.notes,
                  })
                );
                if (ok) setSalaryOpen(false);
              }}
            >
              Simpan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={gradeOpen} onOpenChange={setGradeOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>Atur Bonus Grade - {gradeDraft.gradeLabel}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <Input type="number" placeholder="Tunjangan" value={gradeDraft.allowanceAmount} onChange={(e) => setGradeDraft((v) => ({ ...v, allowanceAmount: e.target.value }))} />
            <Input type="number" placeholder="Kinerja 80" value={gradeDraft.bonusKinerja80} onChange={(e) => setGradeDraft((v) => ({ ...v, bonusKinerja80: e.target.value }))} />
            <Input type="number" placeholder="Kinerja 90" value={gradeDraft.bonusKinerja90} onChange={(e) => setGradeDraft((v) => ({ ...v, bonusKinerja90: e.target.value }))} />
            <Input type="number" placeholder="Kinerja 100" value={gradeDraft.bonusKinerja100} onChange={(e) => setGradeDraft((v) => ({ ...v, bonusKinerja100: e.target.value }))} />
            <Input type="number" placeholder="Team 80" value={gradeDraft.bonusKinerjaTeam80} onChange={(e) => setGradeDraft((v) => ({ ...v, bonusKinerjaTeam80: e.target.value }))} />
            <Input type="number" placeholder="Team 90" value={gradeDraft.bonusKinerjaTeam90} onChange={(e) => setGradeDraft((v) => ({ ...v, bonusKinerjaTeam90: e.target.value }))} />
            <Input type="number" placeholder="Team 100" value={gradeDraft.bonusKinerjaTeam100} onChange={(e) => setGradeDraft((v) => ({ ...v, bonusKinerjaTeam100: e.target.value }))} />
            <Input type="number" placeholder="Disiplin 80" value={gradeDraft.bonusDisiplin80} onChange={(e) => setGradeDraft((v) => ({ ...v, bonusDisiplin80: e.target.value }))} />
            <Input type="number" placeholder="Disiplin 90" value={gradeDraft.bonusDisiplin90} onChange={(e) => setGradeDraft((v) => ({ ...v, bonusDisiplin90: e.target.value }))} />
            <Input type="number" placeholder="Disiplin 100" value={gradeDraft.bonusDisiplin100} onChange={(e) => setGradeDraft((v) => ({ ...v, bonusDisiplin100: e.target.value }))} />
            <Input type="number" placeholder="Prestasi 140" value={gradeDraft.bonusPrestasi140} onChange={(e) => setGradeDraft((v) => ({ ...v, bonusPrestasi140: e.target.value }))} />
            <Input type="number" placeholder="Prestasi 165" value={gradeDraft.bonusPrestasi165} onChange={(e) => setGradeDraft((v) => ({ ...v, bonusPrestasi165: e.target.value }))} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setGradeOpen(false)} disabled={pending}>Batal</Button>
            <Button
              disabled={pending}
              onClick={async () => {
                const ok = await runAction(() =>
                  upsertGradeCompensationConfig({
                    gradeId: gradeDraft.gradeId,
                    allowanceAmount: gradeDraft.allowanceAmount,
                    bonusKinerja80: gradeDraft.bonusKinerja80,
                    bonusKinerja90: gradeDraft.bonusKinerja90,
                    bonusKinerja100: gradeDraft.bonusKinerja100,
                    bonusKinerjaTeam80: gradeDraft.bonusKinerjaTeam80,
                    bonusKinerjaTeam90: gradeDraft.bonusKinerjaTeam90,
                    bonusKinerjaTeam100: gradeDraft.bonusKinerjaTeam100,
                    bonusDisiplin80: gradeDraft.bonusDisiplin80,
                    bonusDisiplin90: gradeDraft.bonusDisiplin90,
                    bonusDisiplin100: gradeDraft.bonusDisiplin100,
                    bonusPrestasi140: gradeDraft.bonusPrestasi140,
                    bonusPrestasi165: gradeDraft.bonusPrestasi165,
                    isActive: true,
                  })
                );
                if (ok) setGradeOpen(false);
              }}
            >
              Simpan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={adjustmentOpen} onOpenChange={setAdjustmentOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Tambah Adjustment Periode</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <select
              className="h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
              value={adjustmentDraft.employeeId}
              onChange={(event) => setAdjustmentDraft((v) => ({ ...v, employeeId: event.target.value }))}
            >
              <option value="">Pilih karyawan</option>
              {salaryConfigs.map((row) => (
                <option key={row.employeeId} value={row.employeeId}>
                  {row.employeeName} · {row.employeeCode}
                </option>
              ))}
            </select>
            <select
              className="h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
              value={adjustmentDraft.adjustmentType}
              onChange={(event) =>
                setAdjustmentDraft((v) => ({ ...v, adjustmentType: event.target.value as "ADDITION" | "DEDUCTION" }))
              }
            >
              <option value="DEDUCTION">DEDUCTION</option>
              <option value="ADDITION">ADDITION</option>
            </select>
            <Input
              type="number"
              placeholder="Nominal"
              value={adjustmentDraft.amount}
              onChange={(event) => setAdjustmentDraft((v) => ({ ...v, amount: event.target.value }))}
            />
            <Input
              placeholder="Alasan"
              value={adjustmentDraft.reason}
              onChange={(event) => setAdjustmentDraft((v) => ({ ...v, reason: event.target.value }))}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAdjustmentOpen(false)} disabled={pending}>Batal</Button>
            <Button
              disabled={pending || !activePeriodId}
              onClick={async () => {
                if (!activePeriodId) return;
                const ok = await runAction(() =>
                  addPayrollAdjustment({
                    periodId: activePeriodId,
                    employeeId: adjustmentDraft.employeeId,
                    adjustmentType: adjustmentDraft.adjustmentType,
                    amount: adjustmentDraft.amount,
                    reason: adjustmentDraft.reason,
                  })
                );
                if (ok) setAdjustmentOpen(false);
              }}
            >
              Simpan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
